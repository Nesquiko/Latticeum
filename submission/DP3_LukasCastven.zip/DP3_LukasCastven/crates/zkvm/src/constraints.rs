use crate::{
    ccs::{
        CCS_C, CCS_NUM_MATRICES, CCS_S, CCSLayout, DECOMP_X_W_LEN, GoldiLocksDP, KAPPA,
        LINEARIZATION_DEGREE, TAU, calc_b_s,
    },
    crypto_consts::{FULL_ROUNDS, M_I_INVERSE_TRANSPOSED, MDS_INVERSE_TRANSPOSED, PARTIAL_ROUNDS},
    poseidon2::{
        GOLDILOCKS_S_BOX_DEGREE, INTERNAL_CONSTS, POSEIDON2_OUT, WIDE_POSEIDON2_13_SPONGE_PASSES,
        WIDE_POSEIDON2_RATE, WIDE_POSEIDON2_WIDTH, WIDTH_16_EXTERNAL_CONSTS,
    },
};
use ark_std::log2;
use cyclotomic_rings::rings::GoldilocksRingNTT;
use latticefold::{arith::CCS, decomposition_parameters::DecompositionParams};
use num_traits::identities::One;
use p3_field::PrimeField64;
use p3_goldilocks::Goldilocks;
use stark_rings_linalg::SparseMatrix;
use std::ops::Neg;

pub type R = GoldilocksRingNTT;

#[derive(Debug)]
pub struct CCSBuilder<'a> {
    /// number of constraints = number of rows in matrices[i]
    m: usize,
    /// layout of the witness vector, also used to derive `n` = number of variables
    layout: &'a CCSLayout,
    /// vector of selector matrices (otherwise known as `M`)
    matrices: Vec<SparseMatrix<R>>,
    /// vector of multisets which signal which matrices to use in constraint (otherwise known as `S`)
    multisets: Vec<Vec<usize>>,
    /// vector of coefficients to be used in constraint (otherwise known as `c`)
    coeffs: Vec<R>,
}

#[derive(Default)]
struct ClaimG1MatrixIndices {
    alpha_v2: usize,
    h1_linear: usize,
    alpha_h1: usize,
    h2_linear: usize,
    alpha_h2: usize,
    claim_linear: usize,
    v2_input: usize,
    h1_input: usize,
    h2_input: usize,
    claim_sum: usize,
}

#[derive(Default)]
struct ClaimG3MatrixIndices {
    zeta_step: usize,
    step_input: usize,
    step_linear: usize,
    zeta_term: usize,
    term_input: usize,
    term_linear: usize,
    claim_sum: usize,
}

impl<'a> CCSBuilder<'a> {
    fn new<const W: usize>(layout: &'a CCSLayout) -> Self {
        Self {
            m: W,
            layout,
            matrices: Vec::new(),
            multisets: Vec::new(),
            coeffs: Vec::new(),
        }
    }

    pub fn create_riscv_ccs<const W: usize>(layout: &'a CCSLayout) -> CCS<R> {
        let mut builder = Self::new::<W>(layout);

        // ivc specific
        builder.ivc_step_inv_constraint();
        builder.ivc_step_after_initial_mds();
        builder.ivc_step_external_initial_rounds();
        builder.ivc_step_internal_rounds();
        builder.ivc_step_external_terminal_rounds();
        builder.ivc_step_result_hash();

        // risc-v specific
        builder.pc_non_branching_constraint();
        builder.add_constraint();
        builder.jal_constraint();
        builder.jalr_constraint();
        builder.bne_constraint();
        builder.auipc_constraint();
        builder.lui_constraint();

        // folding proof specific MUST BE LAST
        builder.folding_proof_linearization_sumcheck();
        builder.folding_proof_linearization_final_check();
        builder.folding_proof_decomposition();

        let claim_g1_indices = builder.preallocate_folding_proof_claim_g1();
        let claim_g3_indices = builder.preallocate_folding_proof_claim_g3();
        builder.folding_proof_folding_sumcheck();
        builder.folding_proof_folding_evaluation_poc();
        builder.folding_proof_final_cm();
        builder.folding_proof_final_u();
        builder.folding_proof_final_x();

        // Must be last preallocation
        builder.preallocate_folding_proof_linearization_inner();
        assert_eq!(
            builder.matrices.len(),
            CCS_NUM_MATRICES,
            "CCS_NUM_MATRICES is stale"
        );

        builder.folding_proof_claim_g1(claim_g1_indices);
        builder.folding_proof_claim_g3(claim_g3_indices);
        builder.folding_proof_linearization_inner();

        builder.build()
    }

    // step * (step * step_inv - 1) = 0 => step*step*step_inv - step = 0.
    fn ivc_step_inv_constraint(&mut self) {
        let matrix_base_idx = self.matrices.len();

        // + step * step * step_inv
        let mut m_step_a = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_step_a.coeffs[IVC_STEP_CONSTR].push((R::one(), self.layout.ivc_h_i_step_idx));

        let mut m_step_b = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_step_b.coeffs[IVC_STEP_CONSTR].push((R::one(), self.layout.ivc_h_i_step_idx));

        let mut m_step_inv = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_step_inv.coeffs[IVC_STEP_CONSTR].push((R::one(), self.layout.ivc_h_i_step_inv_idx));

        self.matrices.push(m_step_a);
        self.matrices.push(m_step_b);
        self.matrices.push(m_step_inv);
        self.multisets.push(vec![
            matrix_base_idx,
            matrix_base_idx + 1,
            matrix_base_idx + 2,
        ]);
        self.coeffs.push(R::one());

        // - step
        let mut m_step_linear = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_step_linear.coeffs[IVC_STEP_CONSTR].push((R::one(), self.layout.ivc_h_i_step_idx));

        self.matrices.push(m_step_linear);
        self.multisets.push(vec![matrix_base_idx + 3]);
        self.coeffs.push(R::one().neg());
    }

    fn ivc_step_after_initial_mds(&mut self) {
        let matrix_base_idx = self.matrices.len();

        let ivc_h_i_state_0_comm_idx = self.layout.ivc_h_i_state_0_comm_idx;
        let ivc_h_i_state_i_comm_idx = self.layout.ivc_h_i_state_i_comm_idx;
        let acc_comm_idx = self.layout.ivc_h_i_acc_i_comm_idx;

        // last round of first sponge pass after external terminal
        let after_external_term_idx: [usize; WIDE_POSEIDON2_WIDTH] =
            self.layout.ivc_h_i_external_terminal[((FULL_ROUNDS / 2 - 1) * WIDE_POSEIDON2_WIDTH)
                ..((FULL_ROUNDS / 2) * WIDE_POSEIDON2_WIDTH)]
                .try_into()
                .expect("failed to convert slice into array of last indices");

        let mut m_after_mds = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        let pass1_state_indices: [usize; WIDE_POSEIDON2_RATE] = [
            self.layout.ivc_h_i_step_idx,
            ivc_h_i_state_0_comm_idx[0],
            ivc_h_i_state_0_comm_idx[1],
            ivc_h_i_state_0_comm_idx[2],
            ivc_h_i_state_0_comm_idx[3],
            ivc_h_i_state_i_comm_idx[0],
            ivc_h_i_state_i_comm_idx[1],
            ivc_h_i_state_i_comm_idx[2],
            ivc_h_i_state_i_comm_idx[3],
            acc_comm_idx[0],
            acc_comm_idx[1],
            acc_comm_idx[2],
        ];

        let pass2_state_indices: [usize; WIDE_POSEIDON2_WIDTH] = [
            acc_comm_idx[3],
            after_external_term_idx[1],
            after_external_term_idx[2],
            after_external_term_idx[3],
            after_external_term_idx[4],
            after_external_term_idx[5],
            after_external_term_idx[6],
            after_external_term_idx[7],
            after_external_term_idx[8],
            after_external_term_idx[9],
            after_external_term_idx[10],
            after_external_term_idx[11],
            // capacity
            after_external_term_idx[12],
            after_external_term_idx[13],
            after_external_term_idx[14],
            after_external_term_idx[15],
        ];

        let m4_4_coeffs: [[u64; 4]; 4] = [[2, 3, 1, 1], [1, 2, 3, 1], [1, 1, 2, 3], [3, 1, 1, 2]];

        for i in 0..WIDE_POSEIDON2_WIDTH {
            let coeff_idx = IVC_H_I_AFTER_MDS_CONSTR[i];
            let after_mds_result_idx = self.layout.ivc_h_i_after_mds_idx[i];

            let mut coeffs_in_row: [u64; WIDE_POSEIDON2_WIDTH] =
                std::iter::repeat(m4_4_coeffs[i % 4])
                    .take(4)
                    .flatten()
                    .collect::<Vec<_>>()
                    .try_into()
                    .expect("failed to convert from m4_4_coeffs to m4_4_coeffs_in_row");

            // at each row, the coeffs repeat, e.g. at row 0, the coeffs will be
            // |2a + 3b + 1c + 1d| + |2e + 3f + 1g + 1h| + |2i + 3j + 1k + 1l| + |2m + 3n + 1o + 1p|
            // but, different group of 4 has double the coeefs, e.g. the first group
            // |4a + 6b + 2c + 2d| + |2e + 3f + 1g + 1h| + |2i + 3j + 1k + 1l| + |2m + 3n + 1o + 1p|

            let doubled_group_start = (i / 4) * 4;
            for j in 0..4 {
                coeffs_in_row[doubled_group_start + j] *= 2;
            }

            let coeffs_in_row: [R; WIDE_POSEIDON2_WIDTH] = coeffs_in_row
                .map(|c| R::from(c))
                .try_into()
                .expect("failed to convert to ring elements");

            m_after_mds.coeffs[coeff_idx].push((R::one(), after_mds_result_idx));

            if i < WIDE_POSEIDON2_WIDTH {
                for k in 0..pass1_state_indices.len() {
                    m_after_mds.coeffs[coeff_idx]
                        .push((coeffs_in_row[k].neg(), pass1_state_indices[k]));
                }
            } else {
                for k in 0..pass2_state_indices.len() {
                    m_after_mds.coeffs[coeff_idx]
                        .push((coeffs_in_row[k].neg(), pass2_state_indices[k]));
                }
            }
        }

        self.matrices.push(m_after_mds);

        self.multisets.push(vec![matrix_base_idx]);
        self.coeffs.push(R::one());
    }

    fn ivc_step_external_initial_rounds(&mut self) {
        let after_init_mds_idx = self.layout.ivc_h_i_after_mds_idx;
        let after_external_init_rounds_idx = self.layout.ivc_h_i_external_initial;
        let external_layers = WIDTH_16_EXTERNAL_CONSTS;
        let external_initial_consts = external_layers.get_initial_constants();
        assert_eq!(external_initial_consts.len(), FULL_ROUNDS / 2);

        let number_of_rounds = FULL_ROUNDS / 2;
        let sponge_passes = WIDE_POSEIDON2_13_SPONGE_PASSES;

        // Create 7 matrices for -(after_init_mds + constant)^7
        let idx_power7_base = self.matrices.len();

        for _ in 0..GOLDILOCKS_S_BOX_DEGREE {
            let mut m_add_round_consts = empty_sparse_matrix(self.m, self.layout.z_vector_size());

            // ==== Round 0 ====
            //  the input is after_init_mds, not the previous external initial round's output
            for pass in 0..sponge_passes {
                let sponge_pass_offset = pass * number_of_rounds * WIDE_POSEIDON2_WIDTH;

                for i in 0..WIDE_POSEIDON2_WIDTH {
                    let coeff_idx = IVC_H_EXT_INIT_ROUNDS_CONSTR[sponge_pass_offset + i];
                    let constant = external_initial_consts[0][i];

                    m_add_round_consts.coeffs[coeff_idx].push((
                        R::one(),
                        after_init_mds_idx[i + pass * WIDE_POSEIDON2_WIDTH],
                    ));
                    m_add_round_consts.coeffs[coeff_idx]
                        .push((from_goldilocks(constant), self.layout.const_1_idx));
                }
            }
            // ==== Round 0 ====

            for round in 1..number_of_rounds {
                let previous_round_idx_offset = (round - 1) * WIDE_POSEIDON2_WIDTH;
                let round_idx_offset = round * WIDE_POSEIDON2_WIDTH;

                for pass in 0..sponge_passes {
                    let sponge_pass_offset = pass * number_of_rounds * WIDE_POSEIDON2_WIDTH;

                    for i in 0..WIDE_POSEIDON2_WIDTH {
                        let coeff_idx =
                            IVC_H_EXT_INIT_ROUNDS_CONSTR[sponge_pass_offset + round_idx_offset + i];
                        let constant = external_initial_consts[round][i];

                        m_add_round_consts.coeffs[coeff_idx].push((
                            R::one(),
                            after_external_init_rounds_idx
                                [sponge_pass_offset + previous_round_idx_offset + i],
                        ));

                        m_add_round_consts.coeffs[coeff_idx]
                            .push((from_goldilocks(constant), self.layout.const_1_idx));
                    }
                }
            }

            self.matrices.push(m_add_round_consts);
        }

        // Multiset for -(after_init_mds + constant)^7 or -(previous_round + constant)^7
        let power7_multiset: Vec<usize> =
            (idx_power7_base..idx_power7_base + GOLDILOCKS_S_BOX_DEGREE).collect();
        self.multisets.push(power7_multiset);
        self.coeffs.push(R::one().neg());

        // Create 1 matrix for MDS^-1 * external_initial
        let idx_inverse_mds = self.matrices.len();
        let mut m_inverse_mds = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        for round in 0..number_of_rounds {
            let round_idx_offset = round * WIDE_POSEIDON2_WIDTH;

            for pass in 0..sponge_passes {
                let sponge_pass_offset = pass * number_of_rounds * WIDE_POSEIDON2_WIDTH;

                for i in 0..WIDE_POSEIDON2_WIDTH {
                    let coeff_idx =
                        IVC_H_EXT_INIT_ROUNDS_CONSTR[sponge_pass_offset + round_idx_offset + i];

                    for (k, &coeff) in MDS_INVERSE_TRANSPOSED[i].iter().enumerate() {
                        m_inverse_mds.coeffs[coeff_idx].push((
                            from_goldilocks(coeff),
                            self.layout.ivc_h_i_external_initial
                                [sponge_pass_offset + round_idx_offset + k],
                        ));
                    }
                }
            }
        }

        self.matrices.push(m_inverse_mds);

        // Create 6 matrices for the 1^6 padding (to match degree 7)
        for _ in 0..(GOLDILOCKS_S_BOX_DEGREE - 1) {
            let mut m_one = empty_sparse_matrix(self.m, self.layout.z_vector_size());
            for i in 0..(sponge_passes * number_of_rounds * WIDE_POSEIDON2_WIDTH) {
                let coeff_idx = IVC_H_EXT_INIT_ROUNDS_CONSTR[i];
                m_one.coeffs[coeff_idx].push((R::one(), self.layout.const_1_idx));
            }
            self.matrices.push(m_one);
        }

        // Multiset for MDS^-1 * external_initial * 1^6
        let inverse_mds_multiset: Vec<usize> =
            (idx_inverse_mds..idx_inverse_mds + GOLDILOCKS_S_BOX_DEGREE).collect();
        self.multisets.push(inverse_mds_multiset);
        self.coeffs.push(R::one());
    }

    fn ivc_step_internal_rounds(&mut self) {
        // last round of first sponge pass after external initial
        let after_ext_init_sponge1_idx: [usize; WIDE_POSEIDON2_WIDTH] =
            self.layout.ivc_h_i_external_initial[((FULL_ROUNDS / 2 - 1) * WIDE_POSEIDON2_WIDTH)
                ..((FULL_ROUNDS / 2) * WIDE_POSEIDON2_WIDTH)]
                .try_into()
                .expect("failed to convert slice into array of last indices");

        let after_ext_init_sponge2_idx: [usize; WIDE_POSEIDON2_WIDTH] =
            self.layout.ivc_h_i_external_initial[((FULL_ROUNDS - 1) * WIDE_POSEIDON2_WIDTH)
                ..((FULL_ROUNDS) * WIDE_POSEIDON2_WIDTH)]
                .try_into()
                .expect("failed to convert slice into array of last indices");

        let after_ext_init_indices = [after_ext_init_sponge1_idx, after_ext_init_sponge2_idx];

        let after_internal_idx = self.layout.ivc_h_i_after_internal_idx;

        let internal_layers = INTERNAL_CONSTS;
        assert_eq!(internal_layers.len(), PARTIAL_ROUNDS);

        let number_of_rounds = PARTIAL_ROUNDS;
        let sponge_passes = WIDE_POSEIDON2_13_SPONGE_PASSES;

        // Create 7 matrices for -(s_in[0] + constant)^7
        let idx_state_0 = self.matrices.len();
        for _ in 0..GOLDILOCKS_S_BOX_DEGREE {
            // State 0 is the only one to which constant and sbox is applied
            let mut m_state_0 = empty_sparse_matrix(self.m, self.layout.z_vector_size());

            for round in 0..number_of_rounds {
                let constant = internal_layers[round];

                for (pass, after_ext_init_idx) in after_ext_init_indices
                    .iter()
                    .enumerate()
                    .take(sponge_passes)
                {
                    let sponge_pass_offset = pass * number_of_rounds * WIDE_POSEIDON2_WIDTH;

                    let round_idx_offset = round * WIDE_POSEIDON2_WIDTH;
                    let coeff_idx =
                        IVC_H_INTERNAL_ROUNDS_CONSTS[sponge_pass_offset + round_idx_offset];

                    if round == 0 {
                        // the input is after external initial, not the previous internal round's output
                        // last_external_internal_round_sponge_pass_X[0] + constant
                        m_state_0.coeffs[coeff_idx].push((R::one(), after_ext_init_idx[0]));
                        m_state_0.coeffs[coeff_idx]
                            .push((from_goldilocks(constant), self.layout.const_1_idx));
                    } else {
                        let previous_round_idx_offset =
                            sponge_pass_offset + (round - 1) * WIDE_POSEIDON2_WIDTH;
                        m_state_0.coeffs[coeff_idx]
                            .push((R::one(), after_internal_idx[previous_round_idx_offset]));
                        m_state_0.coeffs[coeff_idx]
                            .push((from_goldilocks(constant), self.layout.const_1_idx));
                    }
                }
            }
            self.matrices.push(m_state_0);
        }

        let power7_multiset: Vec<usize> =
            (idx_state_0..idx_state_0 + GOLDILOCKS_S_BOX_DEGREE).collect();
        // Multiset for -(s_in[0] + constant)^7
        self.multisets.push(power7_multiset);
        self.coeffs.push(R::one().neg());

        let idx_inverse_m_i = self.matrices.len();
        let mut m_inverse_m_i = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        for round in 0..number_of_rounds {
            for (pass, after_ext_init_idx) in after_ext_init_indices
                .iter()
                .enumerate()
                .take(sponge_passes)
            {
                let sponge_pass_offset = pass * number_of_rounds * WIDE_POSEIDON2_WIDTH;
                let round_idx_offset = round * WIDE_POSEIDON2_WIDTH;

                for i in 0..WIDE_POSEIDON2_WIDTH {
                    let coeff_idx =
                        IVC_H_INTERNAL_ROUNDS_CONSTS[sponge_pass_offset + round_idx_offset + i];

                    for (k, &coeff) in M_I_INVERSE_TRANSPOSED[i].iter().enumerate() {
                        m_inverse_m_i.coeffs[coeff_idx].push((
                            from_goldilocks(coeff),
                            self.layout.ivc_h_i_after_internal_idx
                                [sponge_pass_offset + round_idx_offset + k],
                        ));
                    }

                    // state 0 has the whole add constant and sbox matrix (m_state_0)
                    // created above to be subtracted from the M_I^-1 * s_out,
                    // other states have just M_I^-1 * s_out - s_in
                    if i != 0 {
                        if round == 0 {
                            m_inverse_m_i.coeffs[coeff_idx]
                                .push((R::one().neg(), after_ext_init_idx[round_idx_offset + i]));
                        } else {
                            let previous_round_idx_offset = (round - 1) * WIDE_POSEIDON2_WIDTH;
                            m_inverse_m_i.coeffs[coeff_idx].push((
                                R::one().neg(),
                                after_internal_idx
                                    [sponge_pass_offset + previous_round_idx_offset + i],
                            ));
                        }
                    }
                }
            }
        }
        self.matrices.push(m_inverse_m_i);

        // Create 6 matrices for the 1^6 padding (to match degree 7)
        for _ in 0..(GOLDILOCKS_S_BOX_DEGREE - 1) {
            let mut m_one = empty_sparse_matrix(self.m, self.layout.z_vector_size());

            for i in 0..(sponge_passes * number_of_rounds * WIDE_POSEIDON2_WIDTH) {
                let coeff_idx = IVC_H_INTERNAL_ROUNDS_CONSTS[i];

                m_one.coeffs[coeff_idx].push((R::one(), self.layout.const_1_idx));
            }
            self.matrices.push(m_one);
        }

        // Multiset for M_I^-1 * internal * 1^6
        let inverse_m_i_multiset: Vec<usize> =
            (idx_inverse_m_i..idx_inverse_m_i + GOLDILOCKS_S_BOX_DEGREE).collect();
        self.multisets.push(inverse_m_i_multiset);
        self.coeffs.push(R::one());
    }

    fn ivc_step_external_terminal_rounds(&mut self) {
        // last round of FIRST sponge pass after internal rounds
        let after_round_internal_sponge1_idx: [usize; WIDE_POSEIDON2_WIDTH] =
            self.layout.ivc_h_i_after_internal_idx[((PARTIAL_ROUNDS - 1) * WIDE_POSEIDON2_WIDTH)
                ..(PARTIAL_ROUNDS * WIDE_POSEIDON2_WIDTH)]
                .try_into()
                .expect("failed to convert slice into array of last indices");

        // last round of SECOND sponge pass after internal rounds
        let after_round_internal_sponge2_idx: [usize; WIDE_POSEIDON2_WIDTH] = self
            .layout
            .ivc_h_i_after_internal_idx[((WIDE_POSEIDON2_13_SPONGE_PASSES * PARTIAL_ROUNDS
            - 1)
            * WIDE_POSEIDON2_WIDTH)
            ..(WIDE_POSEIDON2_13_SPONGE_PASSES * PARTIAL_ROUNDS * WIDE_POSEIDON2_WIDTH)]
            .try_into()
            .expect("failed to convert slice into array of last indices");

        let per_sponge_pass_after_internal_indices = [
            after_round_internal_sponge1_idx,
            after_round_internal_sponge2_idx,
        ];

        let after_external_term_rounds_idx = self.layout.ivc_h_i_external_terminal;
        let external_layers = WIDTH_16_EXTERNAL_CONSTS;
        let external_terminal_consts = external_layers.get_terminal_constants();
        assert_eq!(external_terminal_consts.len(), FULL_ROUNDS / 2);

        let number_of_rounds = FULL_ROUNDS / 2;
        let sponge_passes = WIDE_POSEIDON2_13_SPONGE_PASSES;

        // Create 7 matrices for -(after_init_mds + constant)^7
        let idx_power7_base = self.matrices.len();

        for _ in 0..GOLDILOCKS_S_BOX_DEGREE {
            let mut m_add_round_consts = empty_sparse_matrix(self.m, self.layout.z_vector_size());

            // ==== Round 0 ====
            //  the input is after_last_round_internal_idx, not the previous external initial round's output
            for (pass, after_internal_idx) in per_sponge_pass_after_internal_indices
                .iter()
                .enumerate()
                .take(sponge_passes)
            {
                let sponge_pass_offset = pass * number_of_rounds * WIDE_POSEIDON2_WIDTH;

                for i in 0..WIDE_POSEIDON2_WIDTH {
                    let coeff_idx = IVC_H_EXT_TERM_ROUNDS_CONSTR[sponge_pass_offset + i];
                    let constant = external_terminal_consts[0][i];

                    m_add_round_consts.coeffs[coeff_idx].push((R::one(), after_internal_idx[i]));
                    m_add_round_consts.coeffs[coeff_idx]
                        .push((from_goldilocks(constant), self.layout.const_1_idx));
                }
            }
            // ==== Round 0 ====

            for round in 1..number_of_rounds {
                let previous_round_idx_offset = (round - 1) * WIDE_POSEIDON2_WIDTH;
                let round_idx_offset = round * WIDE_POSEIDON2_WIDTH;

                for pass in 0..sponge_passes {
                    let sponge_pass_offset = pass * number_of_rounds * WIDE_POSEIDON2_WIDTH;

                    for i in 0..WIDE_POSEIDON2_WIDTH {
                        let coeff_idx =
                            IVC_H_EXT_TERM_ROUNDS_CONSTR[sponge_pass_offset + round_idx_offset + i];
                        let constant = external_terminal_consts[round][i];

                        m_add_round_consts.coeffs[coeff_idx].push((
                            R::one(),
                            after_external_term_rounds_idx
                                [sponge_pass_offset + previous_round_idx_offset + i],
                        ));

                        m_add_round_consts.coeffs[coeff_idx]
                            .push((from_goldilocks(constant), self.layout.const_1_idx));
                    }
                }
            }

            self.matrices.push(m_add_round_consts);
        }

        // Multiset for -(after_init_mds + constant)^7 or -(previous_round + constant)^7
        let power7_multiset: Vec<usize> =
            (idx_power7_base..idx_power7_base + GOLDILOCKS_S_BOX_DEGREE).collect();
        self.multisets.push(power7_multiset);
        self.coeffs.push(R::one().neg());

        // Create 1 matrix for MDS^-1 * external_initial
        let idx_inverse_mds = self.matrices.len();
        let mut m_inverse_mds = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        for round in 0..number_of_rounds {
            let round_idx_offset = round * WIDE_POSEIDON2_WIDTH;

            for pass in 0..sponge_passes {
                let sponge_pass_offset = pass * number_of_rounds * WIDE_POSEIDON2_WIDTH;
                for i in 0..WIDE_POSEIDON2_WIDTH {
                    let coeff_idx =
                        IVC_H_EXT_TERM_ROUNDS_CONSTR[sponge_pass_offset + round_idx_offset + i];

                    for (k, &coeff) in MDS_INVERSE_TRANSPOSED[i].iter().enumerate() {
                        m_inverse_mds.coeffs[coeff_idx].push((
                            from_goldilocks(coeff),
                            self.layout.ivc_h_i_external_terminal
                                [sponge_pass_offset + round_idx_offset + k],
                        ));
                    }
                }
            }
        }

        self.matrices.push(m_inverse_mds);

        // Create 6 matrices for the 1^6 padding (to match degree 7)
        for _ in 0..(GOLDILOCKS_S_BOX_DEGREE - 1) {
            let mut m_one = empty_sparse_matrix(self.m, self.layout.z_vector_size());
            for i in 0..(sponge_passes * number_of_rounds * WIDE_POSEIDON2_WIDTH) {
                let coeff_idx = IVC_H_EXT_TERM_ROUNDS_CONSTR[i];
                m_one.coeffs[coeff_idx].push((R::one(), self.layout.const_1_idx));
            }
            self.matrices.push(m_one);
        }

        // Multiset for MDS^-1 * external_initial * 1^6
        let inverse_mds_multiset: Vec<usize> =
            (idx_inverse_mds..idx_inverse_mds + GOLDILOCKS_S_BOX_DEGREE).collect();
        self.multisets.push(inverse_mds_multiset);
        self.coeffs.push(R::one());
    }

    fn ivc_step_result_hash(&mut self) {
        // last round of SECOND sponge pass after external terminal
        let after_external_term_idx: [usize; WIDE_POSEIDON2_WIDTH] =
            self.layout.ivc_h_i_external_terminal
                [((FULL_ROUNDS - 1) * WIDE_POSEIDON2_WIDTH)..(FULL_ROUNDS * WIDE_POSEIDON2_WIDTH)]
                .try_into()
                .expect("failed to convert slice into array of last indices");

        let mut m_hash = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        for i in 0..POSEIDON2_OUT {
            let coeff_idx = IVC_H_HASH_CONSTR[i];
            m_hash.coeffs[coeff_idx].push((R::one(), self.layout.ivc_h_i_idx[i]));
            m_hash.coeffs[coeff_idx].push((R::one().neg(), after_external_term_idx[i]));
        }

        let m_hash_idx = self.matrices.len();
        self.matrices.push(m_hash);
        self.multisets.push(vec![m_hash_idx]);
        self.coeffs.push(R::one());
    }

    fn folding_proof_linearization_sumcheck(&mut self) {
        let matrix_base_idx = self.matrices.len();
        let mut m_a = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_gated = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        // lin_claimed_sums[0] == 0
        m_a.coeffs[FP_LIN_INITIAL_CLAIM_ZERO].push((R::one(), self.layout.lin_claimed_sums[0]));

        for i in 0..CCS_S {
            let coeff_idx = FP_LIN_CLAIMED_SUM_EQUALS[i];
            let polyn_evals_start = i * LINEARIZATION_DEGREE;
            // eval[i][0] + eval[i][1] - layout.lin_claimed_sums[i] == 0
            m_a.coeffs[coeff_idx].push((
                R::one(),
                self.layout.lin_eval_polynomials_idx[polyn_evals_start],
            ));
            m_a.coeffs[coeff_idx].push((
                R::one(),
                self.layout.lin_eval_polynomials_idx[polyn_evals_start + 1],
            ));
            m_a.coeffs[coeff_idx].push((R::one().neg(), self.layout.lin_claimed_sums[i]));
        }

        for i in 0..CCS_S {
            let coeff_idx = FP_LIN_CLAIMED_SUM_SUMBTERMS[i];
            m_a.coeffs[coeff_idx].push((R::one(), self.layout.lin_claimed_sums[i + 1])); // +1 skips the first claimed sum which is 0
            for j in 0..LINEARIZATION_DEGREE {
                let subterm_idx = i * LINEARIZATION_DEGREE + j;
                // layout.lin_claimed_sums[i] - layout.lin_claimed_sums_subterms[i + 0] - ... - layout.lin_claimed_sums_subterms[i + j] == 0
                m_a.coeffs[coeff_idx].push((
                    R::one().neg(),
                    self.layout.lin_claimed_sums_subterms[subterm_idx],
                ));
            }
        }
        // layout.lin_expected_eval - layout.lin_claimed_sums[CCS_S] == 0
        m_a.coeffs[FP_LIN_FINAL_CLAIMED_SUM].push((R::one(), self.layout.lin_expected_eval));
        m_a.coeffs[FP_LIN_FINAL_CLAIMED_SUM]
            .push((R::one().neg(), self.layout.lin_claimed_sums[CCS_S]));

        let mut m_b = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_c = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_d = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_e = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_f = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_g = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        let mut m_gate_step = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_gate_step_inv = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        // matches the computation of e = eq(layout.lin_beta_s_idx, layout.lin_eval_point)
        for i in 0..CCS_S {
            // (layout.lin_beta_s_idx[i] * layout.lin_eval_point[i]) - xi_yi[i] == 0
            {
                let coeff_idx = FP_LIN_E_XI_YI[i];
                m_b.coeffs[coeff_idx].push((R::one(), self.layout.lin_beta_s_idx[i]));
                m_c.coeffs[coeff_idx].push((R::one(), self.layout.lin_eval_point[i]));
                m_d.coeffs[coeff_idx].push((R::one().neg(), self.layout.lin_e_xi_yi[i]));
            }

            // (step * step_inv) * (factor[i] - (2*xi_yi[i] - x[i] - y[i] + 1)) == 0
            //  => (self.layout.ivc_h_i_step_inv_idx * self.layout.ivc_h_i_step_idx) *
            //  (self.layout.lin_e_factors[i] - 2*xi_yi[i] + self.layout.lin_beta_s_idx[i] + self.layout.lin_eval_point[i] - 1) == 0
            {
                let coeff_idx = FP_LIN_E_FACTORS[i];
                m_gated.coeffs[coeff_idx].push((R::one(), self.layout.lin_e_factors[i]));
                m_gated.coeffs[coeff_idx].push((R::from(2u64).neg(), self.layout.lin_e_xi_yi[i]));
                m_gated.coeffs[coeff_idx].push((R::one(), self.layout.lin_beta_s_idx[i]));
                m_gated.coeffs[coeff_idx].push((R::one(), self.layout.lin_eval_point[i]));
                m_gated.coeffs[coeff_idx].push((R::one().neg(), self.layout.const_1_idx));

                m_gate_step.coeffs[coeff_idx].push((R::one(), self.layout.ivc_h_i_step_idx));
                m_gate_step_inv.coeffs[coeff_idx]
                    .push((R::one(), self.layout.ivc_h_i_step_inv_idx));
            }

            {
                // (step * step_inv) * (sub_res[i+1] - sub_res[i] * factor[i]) == 0
                // => step*step_inv*sub_res[i+1] - step*step_inv*sub_res[i]*factor[i] == 0
                let coeff_idx = FP_LIN_E_SUB_RES[i + 1]; // +1 to skip the res[0] == 1, which is below
                m_gate_step.coeffs[coeff_idx].push((R::one(), self.layout.ivc_h_i_step_idx));
                m_gate_step_inv.coeffs[coeff_idx]
                    .push((R::one(), self.layout.ivc_h_i_step_inv_idx));

                m_e.coeffs[coeff_idx].push((R::one(), self.layout.lin_e_sub_res[i + 1]));

                m_f.coeffs[coeff_idx].push((R::one(), self.layout.lin_e_sub_res[i]));
                m_g.coeffs[coeff_idx].push((R::one(), self.layout.lin_e_factors[i]));
            }
        }

        // self.layout.lin_e_sub_res[0] - 1 == 0
        m_gated.coeffs[FP_LIN_E_SUB_RES[0]].push((R::one(), self.layout.lin_e_sub_res[0]));
        m_gated.coeffs[FP_LIN_E_SUB_RES[0]].push((R::one().neg(), self.layout.const_1_idx));
        m_gate_step.coeffs[FP_LIN_E_SUB_RES[0]].push((R::one(), self.layout.ivc_h_i_step_idx));
        m_gate_step_inv.coeffs[FP_LIN_E_SUB_RES[0]]
            .push((R::one(), self.layout.ivc_h_i_step_inv_idx));

        self.matrices.push(m_a);
        self.multisets.push(vec![matrix_base_idx]);
        self.coeffs.push(R::one());

        self.matrices.push(m_b);
        self.matrices.push(m_c);

        self.multisets
            .push(vec![matrix_base_idx + 1, matrix_base_idx + 2]);
        self.coeffs.push(R::one());

        self.matrices.push(m_d);
        self.multisets.push(vec![matrix_base_idx + 3]);
        self.coeffs.push(R::one());

        self.matrices.push(m_gated);
        self.matrices.push(m_gate_step.clone());
        self.matrices.push(m_gate_step_inv.clone());
        self.multisets.push(vec![
            matrix_base_idx + 5,
            matrix_base_idx + 6,
            matrix_base_idx + 4,
        ]);
        self.coeffs.push(R::one());

        self.matrices.push(m_gate_step.clone());
        self.matrices.push(m_gate_step_inv.clone());
        self.matrices.push(m_e);
        self.multisets.push(vec![
            matrix_base_idx + 7,
            matrix_base_idx + 8,
            matrix_base_idx + 9,
        ]);
        self.coeffs.push(R::one());

        self.matrices.push(m_gate_step);
        self.matrices.push(m_gate_step_inv);
        self.matrices.push(m_f);
        self.matrices.push(m_g);
        self.multisets.push(vec![
            matrix_base_idx + 10,
            matrix_base_idx + 11,
            matrix_base_idx + 12,
            matrix_base_idx + 13,
        ]);
        self.coeffs.push(R::one().neg());
    }

    fn folding_proof_decomposition(&mut self) {
        let b_s: Vec<GoldilocksRingNTT> = calc_b_s();
        assert_eq!(b_s.len(), self.layout.decomp_y_s_idx.len() / KAPPA);

        let matrix_base_idx = self.matrices.len();
        let mut m_decomp = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        // sum_i(b_s[i] * y_s[i][j]) - cm[j] == 0
        for j in 0..KAPPA {
            let coeff_idx = FP_DECOMP_CM_RECOMP[j];
            for (i, b_i) in b_s.iter().enumerate() {
                let y_idx = self.layout.decomp_y_s_idx[i * KAPPA + j];
                m_decomp.coeffs[coeff_idx].push((*b_i, y_idx));
            }
            m_decomp.coeffs[coeff_idx].push((R::one().neg(), self.layout.decomp_cm_idx[j]));
        }

        // sum_i(b_i * v_s[i][j]) - cm_i.v[j] == 0
        for j in 0..TAU {
            let coeff_idx = FP_DECOMP_V_RECOMP[j];
            for i in 0..GoldiLocksDP::K {
                let v_idx = self.layout.decomp_v_s_idx[i * TAU + j];
                let b_i = b_s[i];
                m_decomp.coeffs[coeff_idx].push((b_i, v_idx));
            }
            m_decomp.coeffs[coeff_idx].push((R::one().neg(), self.layout.decomp_v_idx[j]));
        }

        // sum_i(b_i * u_s[i][j]) - cm_i.u[j] == 0
        for j in 0..CCS_NUM_MATRICES {
            let coeff_idx = FP_DECOMP_U_RECOMP[j];
            for i in 0..GoldiLocksDP::K {
                let u_idx = self.layout.decomp_u_s_idx[i * CCS_NUM_MATRICES + j];
                m_decomp.coeffs[coeff_idx].push((b_s[i], u_idx));
            }
            m_decomp.coeffs[coeff_idx].push((R::one().neg(), self.layout.decomp_u_idx[j]));
        }

        // sum_i(b_i * x_s[i][j]) - cm_i.x_w[j] == 0
        for j in 0..DECOMP_X_W_LEN {
            let coeff_idx = FP_DECOMP_XW_RECOMP[j];
            for i in 0..GoldiLocksDP::K {
                let x_idx = self.layout.decomp_x_s_idx[i * (DECOMP_X_W_LEN + 1) + j];
                m_decomp.coeffs[coeff_idx].push((b_s[i], x_idx));
            }
            m_decomp.coeffs[coeff_idx].push((R::one().neg(), self.layout.decomp_x_w_idx[j]));
        }

        // sum_i(b_i * x_s[i][|x_w|]) - cm_i.h == 0
        for i in 0..GoldiLocksDP::K {
            let h_idx = self.layout.decomp_x_s_idx[i * (DECOMP_X_W_LEN + 1) + DECOMP_X_W_LEN];
            m_decomp.coeffs[FP_DECOMP_H_RECOMP].push((b_s[i], h_idx));
        }
        m_decomp.coeffs[FP_DECOMP_H_RECOMP].push((R::one().neg(), self.layout.decomp_h_idx));

        // sum_i(b_s[i] * y_s_r[i][j]) - cm_r[j] == 0
        for j in 0..KAPPA {
            let coeff_idx = FP_DECOMP_R_CM_RECOMP[j];
            for (i, b_i) in b_s.iter().enumerate() {
                let y_idx = self.layout.decomp_r_y_s_idx[i * KAPPA + j];
                m_decomp.coeffs[coeff_idx].push((*b_i, y_idx));
            }
            m_decomp.coeffs[coeff_idx].push((R::one().neg(), self.layout.decomp_r_cm_idx[j]));
        }

        // sum_i(b_i * v_s_r[i][j]) - cm_i.v[j] == 0
        for j in 0..TAU {
            let coeff_idx = FP_DECOMP_R_V_RECOMP[j];
            for i in 0..GoldiLocksDP::K {
                let v_idx = self.layout.decomp_r_v_s_idx[i * TAU + j];
                let b_i = b_s[i];
                m_decomp.coeffs[coeff_idx].push((b_i, v_idx));
            }
            m_decomp.coeffs[coeff_idx].push((R::one().neg(), self.layout.decomp_r_v_idx[j]));
        }

        // sum_i(b_i * u_s_r[i][j]) - linearized_cm_i.u[j] == 0
        for j in 0..CCS_NUM_MATRICES {
            let coeff_idx = FP_DECOMP_R_U_RECOMP[j];
            for i in 0..GoldiLocksDP::K {
                let u_idx = self.layout.decomp_r_u_s_idx[i * CCS_NUM_MATRICES + j];
                m_decomp.coeffs[coeff_idx].push((b_s[i], u_idx));
            }
            m_decomp.coeffs[coeff_idx].push((R::one().neg(), self.layout.lin_proof_u[j]));
        }

        // sum_i(b_i * x_s_r[i][j]) - cm_i.x_w[j] == 0
        for j in 0..DECOMP_X_W_LEN {
            let coeff_idx = FP_DECOMP_R_XW_RECOMP[j];
            for i in 0..GoldiLocksDP::K {
                let x_idx = self.layout.decomp_r_x_s_idx[i * (DECOMP_X_W_LEN + 1) + j];
                m_decomp.coeffs[coeff_idx].push((b_s[i], x_idx));
            }
            m_decomp.coeffs[coeff_idx].push((R::one().neg(), self.layout.decomp_r_x_w_idx[j]));
        }

        // sum_i(b_i * x_s_r[i][|x_w|]) - cm_i.h == 0
        for i in 0..GoldiLocksDP::K {
            let h_idx = self.layout.decomp_r_x_s_idx[i * (DECOMP_X_W_LEN + 1) + DECOMP_X_W_LEN];
            m_decomp.coeffs[FP_DECOMP_R_H_RECOMP].push((b_s[i], h_idx));
        }
        m_decomp.coeffs[FP_DECOMP_R_H_RECOMP].push((R::one().neg(), self.layout.decomp_r_h_idx));

        self.matrices.push(m_decomp);
        self.multisets.push(vec![matrix_base_idx]);
        self.coeffs.push(R::one());
    }

    fn preallocate_folding_proof_claim_g1(&mut self) -> ClaimG1MatrixIndices {
        let matrix_base_idx = self.matrices.len();

        let m_alpha_v2 = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let m_h1_linear = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        let m_alpha_h1 = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let m_h2_linear = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        let m_alpha_h2 = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let m_claim_linear = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        let m_v2_input = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let m_h1_input = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let m_h2_input = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        let m_claim_sum = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        self.matrices.push(m_alpha_v2);
        self.matrices.push(m_v2_input);
        self.matrices.push(m_h1_linear);

        self.matrices.push(m_alpha_h1);
        self.matrices.push(m_h1_input);
        self.matrices.push(m_h2_linear);

        self.matrices.push(m_alpha_h2);
        self.matrices.push(m_h2_input);
        self.matrices.push(m_claim_linear);

        self.matrices.push(m_claim_sum);

        let mut indexes = ClaimG1MatrixIndices::default();
        self.multisets
            .push(vec![matrix_base_idx, matrix_base_idx + 1]);
        self.coeffs.push(R::one());
        indexes.alpha_v2 = matrix_base_idx;
        indexes.v2_input = matrix_base_idx + 1;

        self.multisets.push(vec![matrix_base_idx + 2]);
        self.coeffs.push(R::one());
        indexes.h1_linear = matrix_base_idx + 2;

        self.multisets
            .push(vec![matrix_base_idx + 3, matrix_base_idx + 4]);
        self.coeffs.push(R::one());
        indexes.alpha_h1 = matrix_base_idx + 3;
        indexes.h1_input = matrix_base_idx + 4;

        self.multisets.push(vec![matrix_base_idx + 5]);
        self.coeffs.push(R::one());
        indexes.h2_linear = matrix_base_idx + 5;

        self.multisets
            .push(vec![matrix_base_idx + 6, matrix_base_idx + 7]);
        self.coeffs.push(R::one());
        indexes.alpha_h2 = matrix_base_idx + 6;
        indexes.h2_input = matrix_base_idx + 7;

        self.multisets.push(vec![matrix_base_idx + 8]);
        self.coeffs.push(R::one());
        indexes.claim_linear = matrix_base_idx + 8;

        self.multisets.push(vec![matrix_base_idx + 9]);
        self.coeffs.push(R::one());
        indexes.claim_sum = matrix_base_idx + 9;

        indexes
    }

    fn folding_proof_claim_g1(&mut self, indices: ClaimG1MatrixIndices) {
        for i in 0..(2 * GoldiLocksDP::K) {
            let alpha_idx = self.layout.fp_claim_g1_alpha_idx[i];
            let h1_idx = self.layout.fp_claim_g1_h1_idx[i];
            let h2_idx = self.layout.fp_claim_g1_h2_idx[i];
            let claim_i_idx = self.layout.fp_claim_g1_terms_idx[i];

            let (v0_idx, v1_idx, v2_idx) = if i < GoldiLocksDP::K {
                (
                    self.layout.decomp_v_s_idx[i * TAU],
                    self.layout.decomp_v_s_idx[i * TAU + 1],
                    self.layout.decomp_v_s_idx[i * TAU + 2],
                )
            } else {
                let r_i = i - GoldiLocksDP::K;
                (
                    self.layout.decomp_r_v_s_idx[r_i * TAU],
                    self.layout.decomp_r_v_s_idx[r_i * TAU + 1],
                    self.layout.decomp_r_v_s_idx[r_i * TAU + 2],
                )
            };

            // decomposed the alpha[i]^(j+1) * v[i][j]
            // with Horner and got
            // alpha[i] * (v[i][0] + alpha[i] * (v[i][1] + alpha[i]*v[i][2]))
            // h1 = alpha[i] * v[i][2] + v[i][1]
            // h2 = alpha[i] * h1 + v[i][0]
            // claim_i = alpha * h2
            // claim_g1 = sum(claim_i)

            // alpha_i * v_i2 - h1_i + v_i1 == 0
            self.matrices[indices.alpha_v2].coeffs[FP_FOLD_G1_H1[i]].push((R::one(), alpha_idx));
            self.matrices[indices.v2_input].coeffs[FP_FOLD_G1_H1[i]].push((R::one(), v2_idx));
            self.matrices[indices.h1_linear].coeffs[FP_FOLD_G1_H1[i]]
                .push((R::one().neg(), h1_idx));
            self.matrices[indices.h1_linear].coeffs[FP_FOLD_G1_H1[i]].push((R::one(), v1_idx));

            // alpha_i * h1_i - h2_i + v_i0 == 0
            self.matrices[indices.alpha_h1].coeffs[FP_FOLD_G1_H2[i]].push((R::one(), alpha_idx));
            self.matrices[indices.h1_input].coeffs[FP_FOLD_G1_H2[i]].push((R::one(), h1_idx));
            self.matrices[indices.h2_linear].coeffs[FP_FOLD_G1_H2[i]]
                .push((R::one().neg(), h2_idx));
            self.matrices[indices.h2_linear].coeffs[FP_FOLD_G1_H2[i]].push((R::one(), v0_idx));

            // alpha_i * h2_i - claim_i == 0
            self.matrices[indices.alpha_h2].coeffs[FP_FOLD_G1_TERM[i]].push((R::one(), alpha_idx));
            self.matrices[indices.h2_input].coeffs[FP_FOLD_G1_TERM[i]].push((R::one(), h2_idx));
            self.matrices[indices.claim_linear].coeffs[FP_FOLD_G1_TERM[i]]
                .push((R::one().neg(), claim_i_idx));

            // sum_i(claim_i) - claim_g1 == 0
            self.matrices[indices.claim_sum].coeffs[FP_FOLD_G1_SUM].push((R::one(), claim_i_idx));
        }
        self.matrices[indices.claim_sum].coeffs[FP_FOLD_G1_SUM]
            .push((R::one().neg(), self.layout.fp_claim_g1_idx));
    }

    fn preallocate_folding_proof_claim_g3(&mut self) -> ClaimG3MatrixIndices {
        let matrix_base_idx = self.matrices.len();

        let m_zeta_step = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let m_step_input = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let m_step_linear = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        let m_zeta_term = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let m_term_input = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let m_term_linear = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        let m_claim_sum = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        self.matrices.push(m_zeta_step);
        self.matrices.push(m_step_input);
        self.matrices.push(m_step_linear);

        self.matrices.push(m_zeta_term);
        self.matrices.push(m_term_input);
        self.matrices.push(m_term_linear);

        self.matrices.push(m_claim_sum);

        let mut indexes = ClaimG3MatrixIndices::default();
        self.multisets
            .push(vec![matrix_base_idx, matrix_base_idx + 1]);
        self.coeffs.push(R::one());
        indexes.zeta_step = matrix_base_idx;
        indexes.step_input = matrix_base_idx + 1;

        self.multisets.push(vec![matrix_base_idx + 2]);
        self.coeffs.push(R::one());
        indexes.step_linear = matrix_base_idx + 2;

        self.multisets
            .push(vec![matrix_base_idx + 3, matrix_base_idx + 4]);
        self.coeffs.push(R::one());
        indexes.zeta_term = matrix_base_idx + 3;
        indexes.term_input = matrix_base_idx + 4;

        self.multisets.push(vec![matrix_base_idx + 5]);
        self.coeffs.push(R::one());
        indexes.term_linear = matrix_base_idx + 5;

        self.multisets.push(vec![matrix_base_idx + 6]);
        self.coeffs.push(R::one());
        indexes.claim_sum = matrix_base_idx + 6;

        indexes
    }

    fn folding_proof_claim_g3(&mut self, indices: ClaimG3MatrixIndices) {
        let t = self.layout.lin_proof_u.len();
        assert_eq!(t, CCS_NUM_MATRICES);

        for i in 0..(2 * GoldiLocksDP::K) {
            let zeta_idx = self.layout.fp_claim_g3_zeta_idx[i];
            let claim_i_idx = self.layout.fp_claim_g3_terms_idx[i];

            // decomposed the zeta[i]^(j+1) * u[i][j]
            // with Horner and got
            // zeta[i] * (u[i][0] + zeta[i] * (u[i][1] + ... + zeta[i] * u[i][t-1]))
            // h0 = zeta[i] * u[i][t-1] + u[i][t-2]
            // h1 = zeta[i] * h0 + u[i][t-3]
            // ...
            // h_{t-2} = zeta[i] * h_{t-3} + u[i][0]
            // claim_i = zeta[i] * h_{t-2}
            // claim_g3 = sum(claim_i)

            for s in 0..(CCS_NUM_MATRICES - 1) {
                let row_idx = FP_FOLD_G3_STEP[i * (CCS_NUM_MATRICES - 1) + s];
                let h_idx = self.layout.fp_claim_g3_h_idx[i * (CCS_NUM_MATRICES - 1) + s];

                let u_tail_idx = if i < GoldiLocksDP::K {
                    self.layout.decomp_u_s_idx[i * CCS_NUM_MATRICES + (t - 1)]
                } else {
                    let r_i = i - GoldiLocksDP::K;
                    self.layout.decomp_r_u_s_idx[r_i * CCS_NUM_MATRICES + (t - 1)]
                };

                let h_prev_or_u_idx = if s == 0 {
                    u_tail_idx
                } else {
                    self.layout.fp_claim_g3_h_idx[i * (CCS_NUM_MATRICES - 1) + (s - 1)]
                };

                let u_next_idx = if i < GoldiLocksDP::K {
                    self.layout.decomp_u_s_idx[i * CCS_NUM_MATRICES + (t - 2 - s)]
                } else {
                    let r_i = i - GoldiLocksDP::K;
                    self.layout.decomp_r_u_s_idx[r_i * CCS_NUM_MATRICES + (t - 2 - s)]
                };

                // zeta_i * prev - h_i_s + u_i[t-2-s] == 0
                self.matrices[indices.zeta_step].coeffs[row_idx].push((R::one(), zeta_idx));
                self.matrices[indices.step_input].coeffs[row_idx].push((R::one(), h_prev_or_u_idx));
                self.matrices[indices.step_linear].coeffs[row_idx].push((R::one().neg(), h_idx));
                self.matrices[indices.step_linear].coeffs[row_idx].push((R::one(), u_next_idx));
            }

            let term_row_idx = FP_FOLD_G3_TERM[i];
            let h_last_idx =
                self.layout.fp_claim_g3_h_idx[i * (CCS_NUM_MATRICES - 1) + (CCS_NUM_MATRICES - 2)];

            // zeta_i * h_i_last - claim_i == 0
            self.matrices[indices.zeta_term].coeffs[term_row_idx].push((R::one(), zeta_idx));
            self.matrices[indices.term_input].coeffs[term_row_idx].push((R::one(), h_last_idx));
            self.matrices[indices.term_linear].coeffs[term_row_idx]
                .push((R::one().neg(), claim_i_idx));

            // sum_i(claim_i) - claim_g3 == 0
            self.matrices[indices.claim_sum].coeffs[FP_FOLD_G3_SUM].push((R::one(), claim_i_idx));
        }

        self.matrices[indices.claim_sum].coeffs[FP_FOLD_G3_SUM]
            .push((R::one().neg(), self.layout.fp_claim_g3_idx));
    }

    fn folding_proof_folding_sumcheck(&mut self) {
        let matrix_base_idx = self.matrices.len();
        let mut m = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        // claimed_sum[0] - claim_g1 - claim_g3 == 0
        m.coeffs[FP_FOLD_SUMCHECK_INITIAL_CLAIM]
            .push((R::one(), self.layout.fp_sumcheck_claimed_sums_idx[0]));
        m.coeffs[FP_FOLD_SUMCHECK_INITIAL_CLAIM]
            .push((R::one().neg(), self.layout.fp_claim_g1_idx));
        m.coeffs[FP_FOLD_SUMCHECK_INITIAL_CLAIM]
            .push((R::one().neg(), self.layout.fp_claim_g3_idx));

        for i in 0..CCS_S {
            let evals_start = i * (2 * GoldiLocksDP::B_SMALL + 1);

            // p_i(0) + p_i(1) - claimed_sum[i] == 0
            m.coeffs[FP_FOLD_SUMCHECK_CLAIMED_SUM_EQUALS[i]].push((
                R::one(),
                self.layout.fp_sumcheck_polynomials_idx[evals_start],
            ));
            m.coeffs[FP_FOLD_SUMCHECK_CLAIMED_SUM_EQUALS[i]].push((
                R::one(),
                self.layout.fp_sumcheck_polynomials_idx[evals_start + 1],
            ));
            m.coeffs[FP_FOLD_SUMCHECK_CLAIMED_SUM_EQUALS[i]]
                .push((R::one().neg(), self.layout.fp_sumcheck_claimed_sums_idx[i]));

            // claimed_sum[i+1] - sum(interpolation_subterms_i) == 0
            m.coeffs[FP_FOLD_SUMCHECK_CLAIMED_SUM_SUBTERMS[i]]
                .push((R::one(), self.layout.fp_sumcheck_claimed_sums_idx[i + 1]));
            for j in 0..(2 * GoldiLocksDP::B_SMALL + 1) {
                let subterm_idx = i * (2 * GoldiLocksDP::B_SMALL + 1) + j;
                m.coeffs[FP_FOLD_SUMCHECK_CLAIMED_SUM_SUBTERMS[i]].push((
                    R::one().neg(),
                    self.layout.fp_sumcheck_claimed_sums_subterms_idx[subterm_idx],
                ));
            }
        }

        // expected_evaluation - claimed_sum[last] == 0
        m.coeffs[FP_FOLD_SUMCHECK_FINAL_CLAIMED_SUM]
            .push((R::one(), self.layout.fp_sumcheck_expected_evaluation_idx));
        m.coeffs[FP_FOLD_SUMCHECK_FINAL_CLAIMED_SUM].push((
            R::one().neg(),
            self.layout.fp_sumcheck_claimed_sums_idx[CCS_S],
        ));

        self.matrices.push(m);
        self.multisets.push(vec![matrix_base_idx]);
        self.coeffs.push(R::one());
    }

    fn folding_proof_folding_evaluation_poc(&mut self) {
        let matrix_base_idx = self.matrices.len();
        let mut m = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        m.coeffs[FP_FOLD_EXPECTED_EVAL].push((R::one(), self.layout.fp_should_equal_s_idx));
        m.coeffs[FP_FOLD_EXPECTED_EVAL].push((
            R::one().neg(),
            self.layout.fp_sumcheck_expected_evaluation_idx,
        ));

        self.matrices.push(m);
        self.multisets.push(vec![matrix_base_idx]);
        self.coeffs.push(R::one());
    }

    fn folding_proof_final_cm(&mut self) {
        let matrix_base_idx = self.matrices.len();
        let mut m_child = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_rho = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_prod = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_sum = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        for j in 0..KAPPA {
            for i in 0..GoldiLocksDP::K {
                let product_row = FP_FOLD_FINAL_CM_PRODUCTS[i * KAPPA + j];
                let product_idx = self.layout.fp_final_cm_products_idx[i * KAPPA + j];

                m_child.coeffs[product_row]
                    .push((R::one(), self.layout.decomp_y_s_idx[i * KAPPA + j]));
                m_rho.coeffs[product_row].push((R::one(), self.layout.fp_rho_s_idx[i]));
                m_prod.coeffs[product_row].push((R::one().neg(), product_idx));
                m_sum.coeffs[FP_FOLD_FINAL_CM_EQ[j]].push((R::one(), product_idx));
            }

            for i in 0..GoldiLocksDP::K {
                let product_offset = GoldiLocksDP::K * KAPPA;
                let product_row = FP_FOLD_FINAL_CM_PRODUCTS[product_offset + i * KAPPA + j];
                let product_idx =
                    self.layout.fp_final_cm_products_idx[product_offset + i * KAPPA + j];

                m_child.coeffs[product_row]
                    .push((R::one(), self.layout.decomp_r_y_s_idx[i * KAPPA + j]));
                m_rho.coeffs[product_row]
                    .push((R::one(), self.layout.fp_rho_s_idx[GoldiLocksDP::K + i]));
                m_prod.coeffs[product_row].push((R::one().neg(), product_idx));
                m_sum.coeffs[FP_FOLD_FINAL_CM_EQ[j]].push((R::one(), product_idx));
            }

            m_sum.coeffs[FP_FOLD_FINAL_CM_EQ[j]]
                .push((R::one().neg(), self.layout.acc_out_cm_idx[j]));
        }

        self.matrices.push(m_child);
        self.matrices.push(m_rho);
        self.multisets
            .push(vec![matrix_base_idx, matrix_base_idx + 1]);
        self.coeffs.push(R::one());

        self.matrices.push(m_prod);
        self.multisets.push(vec![matrix_base_idx + 2]);
        self.coeffs.push(R::one());

        self.matrices.push(m_sum);
        self.multisets.push(vec![matrix_base_idx + 3]);
        self.coeffs.push(R::one());
    }

    fn folding_proof_final_u(&mut self) {
        let matrix_base_idx = self.matrices.len();
        let mut m_eta = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_rho = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_prod = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_step = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_step_inv = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_sum = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        for j in 0..CCS_NUM_MATRICES {
            m_step.coeffs[FP_FOLD_FINAL_U_EQ[j]].push((R::one(), self.layout.ivc_h_i_step_idx));
            m_step_inv.coeffs[FP_FOLD_FINAL_U_EQ[j]]
                .push((R::one(), self.layout.ivc_h_i_step_inv_idx));
            for i in 0..(2 * GoldiLocksDP::K) {
                let product_row = FP_FOLD_FINAL_U_PRODUCTS[i * CCS_NUM_MATRICES + j];
                let product_idx = self.layout.fp_final_u_products_idx[i * CCS_NUM_MATRICES + j];
                let eta_idx = self.layout.fp_eta_s_idx[i * CCS_NUM_MATRICES + j];

                m_eta.coeffs[product_row].push((R::one(), eta_idx));
                m_rho.coeffs[product_row].push((R::one(), self.layout.fp_rho_s_idx[i]));
                m_prod.coeffs[product_row].push((R::one().neg(), product_idx));
                m_sum.coeffs[FP_FOLD_FINAL_U_EQ[j]].push((R::one(), product_idx));
            }

            m_sum.coeffs[FP_FOLD_FINAL_U_EQ[j]]
                .push((R::one().neg(), self.layout.acc_out_u_idx[j]));
        }

        self.matrices.push(m_eta);
        self.matrices.push(m_rho);
        self.multisets
            .push(vec![matrix_base_idx, matrix_base_idx + 1]);
        self.coeffs.push(R::one());

        self.matrices.push(m_prod);
        self.multisets.push(vec![matrix_base_idx + 2]);
        self.coeffs.push(R::one());

        self.matrices.push(m_step);
        self.matrices.push(m_step_inv);
        self.matrices.push(m_sum);
        self.multisets.push(vec![
            matrix_base_idx + 3,
            matrix_base_idx + 4,
            matrix_base_idx + 5,
        ]);
        self.coeffs.push(R::one());
    }

    fn folding_proof_final_x(&mut self) {
        let matrix_base_idx = self.matrices.len();
        let mut m_x = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_rho = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_prod = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_step = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_step_inv = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_sum = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        for j in 0..(DECOMP_X_W_LEN + 1) {
            let sum_row = if j < DECOMP_X_W_LEN {
                FP_FOLD_FINAL_XW_EQ[j]
            } else {
                FP_FOLD_FINAL_H_EQ
            };
            m_step.coeffs[sum_row].push((R::one(), self.layout.ivc_h_i_step_idx));
            m_step_inv.coeffs[sum_row].push((R::one(), self.layout.ivc_h_i_step_inv_idx));
            for i in 0..(2 * GoldiLocksDP::K) {
                let product_row = FP_FOLD_FINAL_X_PRODUCTS[i * (DECOMP_X_W_LEN + 1) + j];
                let product_idx = self.layout.fp_final_x_products_idx[i * (DECOMP_X_W_LEN + 1) + j];
                let x_idx = if i < GoldiLocksDP::K {
                    self.layout.decomp_x_s_idx[i * (DECOMP_X_W_LEN + 1) + j]
                } else {
                    let r_i = i - GoldiLocksDP::K;
                    self.layout.decomp_r_x_s_idx[r_i * (DECOMP_X_W_LEN + 1) + j]
                };

                m_x.coeffs[product_row].push((R::one(), x_idx));
                m_rho.coeffs[product_row].push((R::one(), self.layout.fp_rho_s_idx[i]));
                m_prod.coeffs[product_row].push((R::one().neg(), product_idx));

                m_sum.coeffs[sum_row].push((R::one(), product_idx));
            }

            if j < DECOMP_X_W_LEN {
                m_sum.coeffs[FP_FOLD_FINAL_XW_EQ[j]]
                    .push((R::one().neg(), self.layout.acc_out_x_w_idx[j]));
            } else {
                m_sum.coeffs[FP_FOLD_FINAL_H_EQ].push((R::one().neg(), self.layout.acc_out_h_idx));
            }
        }

        self.matrices.push(m_x);
        self.matrices.push(m_rho);
        self.multisets
            .push(vec![matrix_base_idx, matrix_base_idx + 1]);
        self.coeffs.push(R::one());

        self.matrices.push(m_prod);
        self.multisets.push(vec![matrix_base_idx + 2]);
        self.coeffs.push(R::one());

        self.matrices.push(m_step);
        self.matrices.push(m_step_inv);
        self.matrices.push(m_sum);
        self.multisets.push(vec![
            matrix_base_idx + 3,
            matrix_base_idx + 4,
            matrix_base_idx + 5,
        ]);
        self.coeffs.push(R::one());
    }

    fn preallocate_folding_proof_linearization_inner(&mut self) {
        let matrix_base_idx = self.matrices.len();

        // for each multiset do
        // self.layout.lin_inner ∏_{j in S[i]} u[j]
        // preallocate 7 matrices, because the longest multiset is 7, populate them later, when all
        // multisets are defined. Each of these 7 matrices will be used to constraint one product
        // from elements of `u` as defined in corresponding multiset.
        // m[x] = product of elements u[z] where `z` is from multiset[y]
        for _ in 0..(GOLDILOCKS_S_BOX_DEGREE + 2) {
            // +1 for the matrix holding the self.layout.lin_inner_products_per_multiset
            // +1 for the matrix holding the final inner - c[0]*prod[0] ... == 0
            let m = empty_sparse_matrix(self.m, self.layout.z_vector_size());
            self.matrices.push(m);
        }

        // create the multiset that will be used to multiple matrices holding the
        // u[j] elements
        let multiset = (0..GOLDILOCKS_S_BOX_DEGREE)
            .map(|i| matrix_base_idx + i)
            .collect();
        self.multisets.push(multiset);
        self.coeffs.push(R::one());

        // push the matrix holding the lin_inner_products_per_multiset
        self.multisets
            .push(vec![matrix_base_idx + GOLDILOCKS_S_BOX_DEGREE]);
        self.coeffs.push(R::one().neg());
        // push the matrix holding the final inner - c[0]*prod[0] ... == 0 check
        self.multisets
            .push(vec![matrix_base_idx + GOLDILOCKS_S_BOX_DEGREE + 1]);
        self.coeffs.push(R::one());

        assert_eq!(self.multisets.len(), FP_LIN_INNER_PRODS_PER_MULTISET.len());
    }

    /// MUST BE LAST added constraint
    /// constraints that linearization_inner == Σ_i c[i] * Π_{j in S[i]} u[j].
    /// The formula is:
    ///
    /// ```
    /// let mut sum = 0;
    /// for i in 0..self.multisets.len() {
    ///     let product = 1;
    ///     for j in self.multisets[i].iter() {
    ///         product *= u[j]
    ///     }
    ///     sum += product
    /// }
    /// ```
    fn folding_proof_linearization_inner(&mut self) {
        let matrix_multiset = &self.multisets[self.multisets.len() - 3];
        // fill the matrices according to the multisets with elements from u[j],
        // if the multiset doesn't have 7 elements, then fill the rest with 1s
        for (i, s) in self.multisets.iter().enumerate() {
            assert!(s.len() <= GOLDILOCKS_S_BOX_DEGREE);
            let coeff_idx = FP_LIN_INNER_PRODS_PER_MULTISET[i];

            for (j, &u_j_idx) in s.iter().enumerate() {
                let m = self
                    .matrices
                    .get_mut(matrix_multiset[j])
                    .expect("multiset has index not in self.matrices");
                m.coeffs[coeff_idx].push((R::one(), self.layout.lin_proof_u[u_j_idx]));
            }
            for j in s.len()..GOLDILOCKS_S_BOX_DEGREE {
                let m = self
                    .matrices
                    .get_mut(matrix_multiset[j])
                    .expect("multiset has index not in self.matrices");
                m.coeffs[coeff_idx].push((R::one(), self.layout.const_1_idx));
            }

            let m_prods_idx = self.matrices.len() - 2;
            let m_prods = &mut self.matrices[m_prods_idx];
            m_prods.coeffs[coeff_idx]
                .push((R::one(), self.layout.lin_inner_products_per_multiset[i]));
        }

        // inner - c[0]*self.layout.lin_inner_products_per_multiset[0] - ... == 0
        let m_inner_idx = self.matrices.len() - 1;
        let m_inner = &mut self.matrices[m_inner_idx];
        m_inner.coeffs[FP_LIN_INNER_DECOMP].push((R::one(), self.layout.lin_inner_idx));
        for (i, c) in self.coeffs.iter().enumerate() {
            m_inner.coeffs[FP_LIN_INNER_DECOMP]
                .push((c.neg(), self.layout.lin_inner_products_per_multiset[i]));
        }
    }

    // e * inner == expected_eval
    fn folding_proof_linearization_final_check(&mut self) {
        let matrix_base_idx = self.matrices.len();

        let mut m_e = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_inner = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        let mut m_expected = empty_sparse_matrix(self.m, self.layout.z_vector_size());

        // e * inner - expected_eval == 0
        m_e.coeffs[FP_LIN_INNER_EVAL].push((R::one(), self.layout.lin_e_sub_res[CCS_S]));
        m_inner.coeffs[FP_LIN_INNER_EVAL].push((R::one(), self.layout.lin_inner_idx));
        m_expected.coeffs[FP_LIN_INNER_EVAL].push((R::one().neg(), self.layout.lin_expected_eval));

        self.matrices.push(m_e);
        self.matrices.push(m_inner);
        self.multisets
            .push(vec![matrix_base_idx, matrix_base_idx + 1]);
        self.coeffs.push(R::one());

        self.matrices.push(m_expected);
        self.multisets.push(vec![matrix_base_idx + 2]);
        self.coeffs.push(R::one());
    }

    /// Adds an ADD constraint that handles 32-bit overflow:
    /// z[IS_ADD] * (z[HAS_OVERFLOWN] * 2^32 + z[VAL_RD_OUT] - z[VAL_RS1] - z[VAL_RS2]) = 0
    fn add_constraint(&mut self) {
        let matrix_base_idx = self.matrices.len();

        // Matrix A: selects z[IS_ADD]
        let mut m_a = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_a.coeffs[ADD_CONSTR].push((R::one(), self.layout.is_add_idx));

        // Matrix B: selects (z[HAS_OVERFLOWN] * 2^32 + z[VAL_RD_OUT] - z[VAL_RS1] - z[VAL_RS2])
        let mut m_b = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_b.coeffs[ADD_CONSTR].push((R::from(1u64 << 32), self.layout.has_overflown_idx)); // +2^32 * has_overflown
        m_b.coeffs[ADD_CONSTR].push((R::one(), self.layout.val_rd_out_idx)); // +val_rd_out
        m_b.coeffs[ADD_CONSTR].push((R::one().neg(), self.layout.val_rs1_idx)); // -val_rs1
        m_b.coeffs[ADD_CONSTR].push((R::one().neg(), self.layout.val_rs2_idx)); // -val_rs2

        self.matrices.push(m_a);
        self.matrices.push(m_b);

        // Add multiset: A * B
        self.multisets
            .push(vec![matrix_base_idx, matrix_base_idx + 1]);
        self.coeffs.push(R::one());
    }

    /// Adds a PC constraint for non-branching instructions:
    /// (1 - z[IS_BRANCHING]) * (z[PC_OUT] - z[PC_IN] - z[INST_SIZE]) = 0
    fn pc_non_branching_constraint(&mut self) {
        let matrix_base_idx = self.matrices.len();

        // Matrix A: selects (1 - z[IS_BRANCHING])
        let mut m_a = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_a.coeffs[PC_NON_BRANCH_CONSTR].push((R::one(), self.layout.const_1_idx));
        m_a.coeffs[PC_NON_BRANCH_CONSTR].push((R::one().neg(), self.layout.is_branching_idx));

        // Matrix B: selects (z[PC_OUT] - z[PC_IN] - z[INSTRUCTION_SIZE])
        let mut m_b = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_b.coeffs[PC_NON_BRANCH_CONSTR].push((R::one(), self.layout.pc_out_idx));
        m_b.coeffs[PC_NON_BRANCH_CONSTR].push((R::one().neg(), self.layout.pc_in_idx));
        m_b.coeffs[PC_NON_BRANCH_CONSTR].push((R::one().neg(), self.layout.instruction_size_idx));

        self.matrices.push(m_a);
        self.matrices.push(m_b);

        // Add multiset: A * B
        self.multisets
            .push(vec![matrix_base_idx, matrix_base_idx + 1]);
        self.coeffs.push(R::one());
    }

    /// Adds a JAL constraint that ensures the return address is written correctly:
    /// z[IS_JAL] * (z[VAL_RD_OUT] - (z[PC_IN] + z[INSTRUCTION_SIZE])) = 0
    fn jal_constraint(&mut self) {
        let matrix_base_idx = self.matrices.len();

        // Matrix A: selects z[IS_JAL]
        let mut m_a = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_a.coeffs[JAL_CONSTR].push((R::one(), self.layout.is_jal_idx));

        // Matrix B: selects (z[VAL_RD_OUT] - z[PC_IN] - z[INSTRUCTION_SIZE])
        let mut m_b = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_b.coeffs[JAL_CONSTR].push((R::one(), self.layout.val_rd_out_idx));
        m_b.coeffs[JAL_CONSTR].push((R::one().neg(), self.layout.pc_in_idx));
        m_b.coeffs[JAL_CONSTR].push((R::one().neg(), self.layout.instruction_size_idx));

        self.matrices.push(m_a);
        self.matrices.push(m_b);

        // Add multiset: A * B
        self.multisets
            .push(vec![matrix_base_idx, matrix_base_idx + 1]);
        self.coeffs.push(R::one());
    }

    /// Adds a JALR constraint that ensures the return address is written correctly:
    /// z[IS_JALR] * (z[VAL_RD_OUT] - (z[PC_IN] + z[INSTRUCTION_SIZE])) = 0
    fn jalr_constraint(&mut self) {
        let matrix_base_idx = self.matrices.len();

        // Matrix A: selects z[IS_JALR]
        let mut m_a = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_a.coeffs[JALR_CONSTR].push((R::one(), self.layout.is_jalr_idx));

        // Matrix B: selects (z[VAL_RD_OUT] - z[PC_IN] - z[INSTRUCTION_SIZE])
        let mut m_b = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_b.coeffs[JALR_CONSTR].push((R::one(), self.layout.val_rd_out_idx));
        m_b.coeffs[JALR_CONSTR].push((R::one().neg(), self.layout.pc_in_idx));
        m_b.coeffs[JALR_CONSTR].push((R::one().neg(), self.layout.instruction_size_idx));

        self.matrices.push(m_a);
        self.matrices.push(m_b);

        // Add multiset: A * B
        self.multisets
            .push(vec![matrix_base_idx, matrix_base_idx + 1]);
        self.coeffs.push(R::one());
    }

    /// Adds a BNE constraint that ensures the branch condition is correct:
    /// z[IS_BNE] * (1 - z[IS_BRANCHING]) * (z[VAL_RS1] - z[VAL_RS2]) = 0
    ///
    /// This constraint ensures that:
    /// - If is_branching = 0 (branch not taken), then rs1 - rs2 = 0, so rs1 = rs2
    /// - If is_branching = 1 (branch taken), then rs1 - rs2 != 0 and constraint becomes 0 * (...) = 0
    ///
    /// Since the Goldilocks field is used and it is proving a 32-bit machine,
    /// the rs1 - rs2 = 0 can be directly constrained without overflow.
    fn bne_constraint(&mut self) {
        let matrix_base_idx = self.matrices.len();

        // Matrix A: selects z[IS_BNE]
        let mut m_a = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_a.coeffs[BNE_CONSTR].push((R::one(), self.layout.is_bne_idx));

        // Matrix B: selects (1 - z[IS_BRANCHING])
        let mut m_b = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_b.coeffs[BNE_CONSTR].push((R::one(), self.layout.const_1_idx));
        m_b.coeffs[BNE_CONSTR].push((R::one().neg(), self.layout.is_branching_idx));

        // Matrix C: selects (z[VAL_RS1] - z[VAL_RS2])
        let mut m_c = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_c.coeffs[BNE_CONSTR].push((R::one(), self.layout.val_rs1_idx));
        m_c.coeffs[BNE_CONSTR].push((R::one().neg(), self.layout.val_rs2_idx));

        self.matrices.push(m_a);
        self.matrices.push(m_b);
        self.matrices.push(m_c);

        // Multiset: A * B * C = IS_BNE * (1 - IS_BRANCHING) * (RS1 - RS2)
        self.multisets.push(vec![
            matrix_base_idx,
            matrix_base_idx + 1,
            matrix_base_idx + 2,
        ]);
        self.coeffs.push(R::one());
    }

    /// Adds an AUIPC constraint that handles 32-bit overflow:
    /// z[IS_AUIPC] * (z[HAS_OVERFLOWN] * 2^32 + z[VAL_RD_OUT] - z[PC_IN] - (z[IMM] * 2^12)) = 0
    ///
    /// AUIPC computes: rd = pc + (imm << 12) with 32-bit wrapping
    /// The constraint ensures this computation is performed correctly, including overflow handling.
    pub fn auipc_constraint(&mut self) {
        let matrix_base_idx = self.matrices.len();

        // Matrix A: selects z[IS_AUIPC]
        let mut m_a = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_a.coeffs[AUIPC_CONSTR].push((R::one(), self.layout.is_auipc_idx));

        // Matrix B: selects (z[HAS_OVERFLOWN] * 2^32 + z[VAL_RD_OUT] - z[PC_IN] - (z[IMM] * 2^12))
        let mut m_b = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_b.coeffs[AUIPC_CONSTR].push((R::from(1u64 << 32), self.layout.has_overflown_idx)); // +2^32 * has_overflown
        m_b.coeffs[AUIPC_CONSTR].push((R::one(), self.layout.val_rd_out_idx)); // +rd_out
        m_b.coeffs[AUIPC_CONSTR].push((R::one().neg(), self.layout.pc_in_idx)); // -pc_in
        m_b.coeffs[AUIPC_CONSTR].push((R::from(1u64 << 12).neg(), self.layout.imm_idx)); // -(imm * 2^12)

        self.matrices.push(m_a);
        self.matrices.push(m_b);

        // Multiset: A * B
        self.multisets
            .push(vec![matrix_base_idx, matrix_base_idx + 1]);
        self.coeffs.push(R::one());
    }

    /// Adds a LUI constraint that ensures the computation is correct:
    /// z[IS_LUI] * (z[VAL_RD_OUT] - (z[IMM] * 2^12)) = 0
    ///
    /// LUI computes: rd = imm << 12 (load upper immediate)
    /// where z[IMM] contains the unshifted immediate value
    /// and the constraint performs the shift by multiplying by 2^12
    fn lui_constraint(&mut self) {
        let matrix_base_idx = self.matrices.len();

        // Matrix A: selects z[IS_LUI]
        let mut m_a = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_a.coeffs[LUI_CONSTR].push((R::one(), self.layout.is_lui_idx));

        // Matrix B: selects (z[VAL_RD_OUT] - (z[IMM] * 2^12))
        let mut m_b = empty_sparse_matrix(self.m, self.layout.z_vector_size());
        m_b.coeffs[LUI_CONSTR].push((R::one(), self.layout.val_rd_out_idx)); // +rd_out
        m_b.coeffs[LUI_CONSTR].push((R::from(1u64 << 12).neg(), self.layout.imm_idx)); // -(imm * 2^12)

        self.matrices.push(m_a);
        self.matrices.push(m_b);

        // Multiset: A * B
        self.multisets
            .push(vec![matrix_base_idx, matrix_base_idx + 1]);
        self.coeffs.push(R::one());
    }

    pub fn build(self) -> CCS<R> {
        let mut ccs = CCS::<R> {
            m: self.m,
            n: self.layout.z_vector_size(), // z-vector structure: [x_ccs(1), 1, w_ccs(layout.size)] = layout.size + 2 total
            l: CCSLayout::X_ELEMS_SIZE,     // Number of public inputs (memory commitment)
            t: self.matrices.len(),
            q: self.multisets.len(),
            d: self.multisets.iter().map(|s| s.len()).max().unwrap_or(1),
            s: log2(self.m) as usize,
            s_prime: log2(self.layout.z_vector_size()) as usize,
            M: self.matrices,
            S: self.multisets,
            c: self.coeffs,
        };

        // The latticefold library will apply additional padding based on the formula:
        // len = max((n - l - 1) * L, m).next_power_of_two()
        // With our values: n=layout.size+1, l=0, L=1, m=original_m
        // This gives: len = max(layout.size, original_m).next_power_of_two()
        // Need to set dimensions to match this expected padding
        let latticefold_padded_size =
            usize::max((ccs.n - ccs.l - 1) * 1, self.m).next_power_of_two();

        ccs.m = latticefold_padded_size;
        ccs.s = log2(latticefold_padded_size) as usize;
        ccs.M.iter_mut().for_each(|mat| {
            mat.pad_rows(latticefold_padded_size);
        });

        ccs
    }
}

fn empty_sparse_matrix(m: usize, n: usize) -> SparseMatrix<GoldilocksRingNTT> {
    SparseMatrix {
        nrows: m,
        ncols: n,
        coeffs: vec![vec![]; m],
    }
}

fn from_goldilocks(g: Goldilocks) -> R {
    R::from(g.as_canonical_u64())
}

// Indices of the constraints
const ADD_CONSTR: usize = 0;
const PC_NON_BRANCH_CONSTR: usize = ADD_CONSTR + 1;
const JAL_CONSTR: usize = PC_NON_BRANCH_CONSTR + 1;
const JALR_CONSTR: usize = JAL_CONSTR + 1;
const BNE_CONSTR: usize = JALR_CONSTR + 1;
const AUIPC_CONSTR: usize = BNE_CONSTR + 1;
const LUI_CONSTR: usize = AUIPC_CONSTR + 1;

const IVC_STEP_CONSTR: usize = LUI_CONSTR + 1;

const IVC_H_I_AFTER_MDS_CONSTR: [usize; WIDE_POSEIDON2_13_SPONGE_PASSES * WIDE_POSEIDON2_WIDTH] =
    index_array(IVC_STEP_CONSTR + 1);

const IVC_H_EXT_INIT_ROUNDS_CONSTR: [usize; FULL_ROUNDS * WIDE_POSEIDON2_WIDTH] =
    index_array(last(IVC_H_I_AFTER_MDS_CONSTR) + 1);

const IVC_H_INTERNAL_ROUNDS_CONSTS: [usize;
    WIDE_POSEIDON2_13_SPONGE_PASSES * PARTIAL_ROUNDS * WIDE_POSEIDON2_WIDTH] =
    index_array(last(IVC_H_EXT_INIT_ROUNDS_CONSTR) + 1);

const IVC_H_EXT_TERM_ROUNDS_CONSTR: [usize; FULL_ROUNDS * WIDE_POSEIDON2_WIDTH] =
    index_array(last(IVC_H_INTERNAL_ROUNDS_CONSTS) + 1);

const IVC_H_HASH_CONSTR: [usize; POSEIDON2_OUT] =
    index_array(last(IVC_H_EXT_TERM_ROUNDS_CONSTR) + 1);

const FP_LIN_INITIAL_CLAIM_ZERO: usize = last(IVC_H_HASH_CONSTR) + 1;
const FP_LIN_CLAIMED_SUM_EQUALS: [usize; CCS_S] = index_array(FP_LIN_INITIAL_CLAIM_ZERO + 1);
const FP_LIN_CLAIMED_SUM_SUMBTERMS: [usize; CCS_S] =
    index_array(last(FP_LIN_CLAIMED_SUM_EQUALS) + 1);
const FP_LIN_FINAL_CLAIMED_SUM: usize = last(FP_LIN_CLAIMED_SUM_SUMBTERMS) + 1;
const FP_LIN_E_XI_YI: [usize; CCS_S] = index_array(FP_LIN_FINAL_CLAIMED_SUM + 1);
const FP_LIN_E_FACTORS: [usize; CCS_S] = index_array(last(FP_LIN_E_XI_YI) + 1);
const FP_LIN_E_SUB_RES: [usize; CCS_S + 1] = index_array(last(FP_LIN_E_FACTORS) + 1);
const FP_LIN_INNER_EVAL: usize = last(FP_LIN_E_SUB_RES) + 1;
const FP_LIN_INNER_PRODS_PER_MULTISET: [usize; CCS_C] = index_array(FP_LIN_INNER_EVAL + 1);
const FP_LIN_INNER_DECOMP: usize = last(FP_LIN_INNER_PRODS_PER_MULTISET) + 1;
const FP_DECOMP_CM_RECOMP: [usize; KAPPA] = index_array(FP_LIN_INNER_DECOMP + 1);
const FP_DECOMP_V_RECOMP: [usize; TAU] = index_array(last(FP_DECOMP_CM_RECOMP) + 1);
const FP_DECOMP_U_RECOMP: [usize; CCS_NUM_MATRICES] = index_array(last(FP_DECOMP_V_RECOMP) + 1);
const FP_DECOMP_XW_RECOMP: [usize; DECOMP_X_W_LEN] = index_array(last(FP_DECOMP_U_RECOMP) + 1);
const FP_DECOMP_H_RECOMP: usize = last(FP_DECOMP_XW_RECOMP) + 1;
const FP_DECOMP_R_CM_RECOMP: [usize; KAPPA] = index_array(FP_DECOMP_H_RECOMP + 1);
const FP_DECOMP_R_V_RECOMP: [usize; TAU] = index_array(last(FP_DECOMP_R_CM_RECOMP) + 1);
const FP_DECOMP_R_U_RECOMP: [usize; CCS_NUM_MATRICES] = index_array(last(FP_DECOMP_R_V_RECOMP) + 1);
const FP_DECOMP_R_XW_RECOMP: [usize; DECOMP_X_W_LEN] = index_array(last(FP_DECOMP_R_U_RECOMP) + 1);
const FP_DECOMP_R_H_RECOMP: usize = last(FP_DECOMP_R_XW_RECOMP) + 1;
const FP_FOLD_G1_H1: [usize; 2 * GoldiLocksDP::K] = index_array(FP_DECOMP_R_H_RECOMP + 1);
const FP_FOLD_G1_H2: [usize; 2 * GoldiLocksDP::K] = index_array(last(FP_FOLD_G1_H1) + 1);
const FP_FOLD_G1_TERM: [usize; 2 * GoldiLocksDP::K] = index_array(last(FP_FOLD_G1_H2) + 1);
const FP_FOLD_G1_SUM: usize = last(FP_FOLD_G1_TERM) + 1;
const FP_FOLD_G3_STEP: [usize; 2 * GoldiLocksDP::K * (CCS_NUM_MATRICES - 1)] =
    index_array(FP_FOLD_G1_SUM + 1);
const FP_FOLD_G3_TERM: [usize; 2 * GoldiLocksDP::K] = index_array(last(FP_FOLD_G3_STEP) + 1);
const FP_FOLD_G3_SUM: usize = last(FP_FOLD_G3_TERM) + 1;
const FP_FOLD_SUMCHECK_INITIAL_CLAIM: usize = FP_FOLD_G3_SUM + 1;
const FP_FOLD_SUMCHECK_CLAIMED_SUM_EQUALS: [usize; CCS_S] =
    index_array(FP_FOLD_SUMCHECK_INITIAL_CLAIM + 1);
const FP_FOLD_SUMCHECK_CLAIMED_SUM_SUBTERMS: [usize; CCS_S] =
    index_array(last(FP_FOLD_SUMCHECK_CLAIMED_SUM_EQUALS) + 1);
const FP_FOLD_SUMCHECK_FINAL_CLAIMED_SUM: usize = last(FP_FOLD_SUMCHECK_CLAIMED_SUM_SUBTERMS) + 1;
const FP_FOLD_EXPECTED_EVAL: usize = FP_FOLD_SUMCHECK_FINAL_CLAIMED_SUM + 1;
const FP_FOLD_FINAL_CM_PRODUCTS: [usize; 2 * GoldiLocksDP::K * KAPPA] =
    index_array(FP_FOLD_EXPECTED_EVAL + 1);
const FP_FOLD_FINAL_CM_EQ: [usize; KAPPA] = index_array(last(FP_FOLD_FINAL_CM_PRODUCTS) + 1);
const FP_FOLD_FINAL_U_PRODUCTS: [usize; 2 * GoldiLocksDP::K * CCS_NUM_MATRICES] =
    index_array(last(FP_FOLD_FINAL_CM_EQ) + 1);
const FP_FOLD_FINAL_U_EQ: [usize; CCS_NUM_MATRICES] =
    index_array(last(FP_FOLD_FINAL_U_PRODUCTS) + 1);
const FP_FOLD_FINAL_X_PRODUCTS: [usize; 2 * GoldiLocksDP::K * (DECOMP_X_W_LEN + 1)] =
    index_array(last(FP_FOLD_FINAL_U_EQ) + 1);
const FP_FOLD_FINAL_XW_EQ: [usize; DECOMP_X_W_LEN] =
    index_array(last(FP_FOLD_FINAL_X_PRODUCTS) + 1);
const FP_FOLD_FINAL_H_EQ: usize = last(FP_FOLD_FINAL_XW_EQ) + 1;

const fn last<const WIDTH: usize>(arr: [usize; WIDTH]) -> usize {
    *arr.last().expect("there is no last element")
}

const fn index_array<const WIDTH: usize>(start: usize) -> [usize; WIDTH] {
    let mut arr = [0; WIDTH];
    let mut i = 0;
    while i < WIDTH {
        arr[i] = start + i;
        i += 1;
    }
    arr
}

#[cfg(feature = "debug")]
use crate::ivc::IVCStepInput;
#[cfg(feature = "debug")]
use stark_rings::Ring;
#[cfg(feature = "debug")]
use tracing::{Level, instrument};

#[cfg(feature = "debug")]
#[instrument(skip_all, level = Level::DEBUG)]
pub fn check_relation_debug(
    ccs: &CCS<GoldilocksRingNTT>,
    z: &Vec<GoldilocksRingNTT>,
    ivc_step: &IVCStepInput,
) {
    use latticefold::arith::Arith;
    use vm::riscvm::riscv_isa::Instruction;

    let inst = ivc_step.trace.instruction.inst;

    match inst {
        Instruction::ADD { .. }
        | Instruction::ADDI { .. }
        | Instruction::BNE { .. }
        | Instruction::LUI { .. }
        | Instruction::AUIPC { .. }
        | Instruction::JAL { .. }
        | Instruction::JALR { .. }
        | Instruction::SW { .. } => {
            ccs.check_relation(z).unwrap_or_else(|e| {
                if let latticefold::arith::error::CSError::NotSatisfied(row_idx) = &e {
                    tracing::error!(row_idx = *row_idx, "ccs row failed");
                    for (matrix_idx, matrix) in ccs.M.iter().enumerate() {
                        if !matrix.coeffs[*row_idx].is_empty() {
                            let row_eval = matrix.coeffs[*row_idx]
                                .iter()
                                .fold(R::ZERO, |acc, (coeff, col_idx)| acc + (*coeff * z[*col_idx]));
                            tracing::error!(matrix_idx, row_eval = ?row_eval, coeffs = ?matrix.coeffs[*row_idx], "non-empty matrix row");
                        }
                    }
                }
                panic!("CCS relation failed for {:?}: {:?}", inst, e);
            });
        }
        inst => {
            panic!("unchecked instruction {:?}", inst);
        }
    }
}
